<script setup lang="ts">
import { ref,watch } from 'vue'
import { useRoute,useRouter } from 'vue-router'
import { api,ui,run } from './api'
const route=useRoute(),router=useRouter(),task=ref<any>(null),taskCode=ref(sessionStorage.getItem('bio_task')??''),queryCode=ref('')
watch(()=>route.params.code,async(code)=>{if(code)await run(async()=>{task.value=await api('/tasks/'+encodeURIComponent(String(code)));taskCode.value=task.value.code;sessionStorage.setItem('bio_task',task.value.code)},'')},{immediate:true})
async function join(){if(taskCode.value)await router.push('/tasks/'+encodeURIComponent(taskCode.value.trim()))}
async function recover(){await run(async()=>{const state=await api('/session',{code:queryCode.value,role:'student'});queryCode.value='';ui.role='student';ui.caseIds=[state.case_id];router.push('/cases/'+state.case_id)},'已找回实验案例')}
</script>
<template><section class="hero"><p class="eyebrow">探索关联 · 记录证据 · 修订解释</p><h1>把知识与实验<br>连成学习的过程</h1><p class="lead">从理解生物功能网络，到分析实验现象，在原理与证据之间建立联系。</p></section>
<div class="module-grid"><RouterLink to="/knowledge" class="module-card"><span class="module-index">01 / 知识探索</span><h2>生物知识网络</h2><p>查询代谢物、蛋白／酶、基因与通路，理解它们之间的关联和依据。</p><b>进入知识网络 →</b></RouterLink><RouterLink to="/experiment" class="module-card dark"><span class="module-index">02 / 实验复盘</span><h2>实验分析与复盘</h2><p>记录自己的判断，补充证据，查看教师反馈，再用验证计划推进分析。</p><b>进入实验复盘 →</b></RouterLink></div>
<div class="two-col"><section class="panel"><p class="eyebrow">课堂任务</p><h2>我的课堂任务</h2><p class="muted">输入教师提供的任务码，查看实验要求与相关知识。</p><form @submit.prevent="join" class="inline-form"><label class="grow">任务码<input v-model="taskCode" required maxlength="30" placeholder="请输入任务码"></label><button>查看任务</button></form><div v-if="task" class="task-detail"><h3>{{task.title}}</h3><p class="preserve">{{task.instructions}}</p><p class="muted">版本 {{task.version}} · {{task.status}} · {{task.due_at||'未设置截止时间'}}</p><p>{{task.knowledge_note}}</p><div class="chips"><RouterLink v-for="entry in task.knowledge.items" :key="entry.id" :to="{path:'/knowledge/'+entry.id,query:{task:task.code}}">{{entry.name}} ↗</RouterLink></div><RouterLink class="button" :to="{path:'/experiment',query:{task:task.code}}">记录本次实验</RouterLink></div></section>
<section class="panel"><p class="eyebrow">学习记录</p><h2>找回实验案例</h2><p class="muted">用保存的私有查询码查看反馈。换一台设备时，也可以使用同一个查询码。</p><form @submit.prevent="recover"><label>私有查询码<input type="password" v-model="queryCode" required autocomplete="off"></label><button>找回案例</button></form><div v-if="ui.caseIds.length" class="chips"><RouterLink v-for="id in ui.caseIds" :key="id" :to="'/cases/'+id">案例 #{{id}}</RouterLink></div></section></div>
</template>
