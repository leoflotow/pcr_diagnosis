# -*- coding: utf-8 -*-
"""
生物实验智析助手 - Streamlit 应用
功能：根据实验现象和参数，诊断PCR电泳异常原因
"""

import os
from dotenv import load_dotenv
if os.getenv("BIO_CONFIG_DISABLED") != "1":
    load_dotenv()

import streamlit as st
from branding import PRODUCT_NAME, PRODUCT_SUBTITLE, CURRENT_MODULE
from ui_design import apply_design_system
import pandas as pd
import sqlite3
import os
import re
import json
import uuid
import hashlib
from io import BytesIO
from PIL import Image, UnidentifiedImageError
from datetime import datetime
from diagnosis_normalization import build_normalized_case, explain_normalized_case
from diagnosis_rule_engine_v2 import evaluate_rules_v2
from navigation_state import get_home_page
import case_storage
import experiment_business
from experiment_business import _dedupe_keep_order, append_report_section, build_diagnosis_context, build_evidence_summary, build_feedback_loop_summary_for_report, build_primary_diagnosis_from_rules_v2, build_ranked_results, build_report_consistency_status, build_review_suggestions, compute_confidence_level, convert_rules_v2_eval_to_display_results, count_hit_evidence, detect_missing_key_info, format_diagnosis_result_text, get_action_advice_by_reason, is_classroom_record, is_missing_value, normalize_reason_for_report, normalize_report_value, parse_all_candidates, parse_candidate_result_item, parse_followup_data, safe_to_float
import ai_config
from evidence_support import confirmed_description, normalize_cause_label, parse_json, rules_version, template_mass_ng, positive_number

try:
    # 兼容客户端仅请求 DeepSeek 官方接口。
    from openai import OpenAI
except:
    OpenAI = None

# 数据库路径
DB_PATH = os.getenv("PCR_DIAGNOSIS_DB_PATH", "data/app.db")

# 规则文件路径
RULES_PATH = "rules.csv"
LEGACY_RULES_PATH = "rules_v2.csv"
# 上传图片保存目录
UPLOAD_DIR = os.getenv("PCR_DIAGNOSIS_UPLOAD_DIR", "uploads")
# 页面里使用的实验现象选项（也用于规则校验）
ABNORMALITY_OPTIONS = [
    "无条带",
    "条带弱",
    "多条带或非特异扩增",
    "条带大小不对",
    "条带拖尾或弥散",
    "阴性对照有带",
    "阳性对照无带",
    "条带畸形",
]
# 规则库必要字段（匹配新版 rules.csv 规则矩阵结构）
REQUIRED_RULE_COLUMNS = [
    "rule_id", "abnormality", "band_pattern", "cause", "priority",
    "positive_control", "negative_control", "template_condition",
    "annealing_temp_condition", "text_hint", "required_fields",
    "base_score", "evidence_text", "suggestion", "enabled"
]

# 保留旧常量名以兼容既有导入；所有实际请求统一为 DeepSeek。
BIGMODEL_DEFAULT_BASE_URL = ai_config.BASE_URL
BIGMODEL_MODEL = ai_config.MODEL
BIGMODEL_TIMEOUT_SECONDS = 8
BIGMODEL_TEMPERATURE = 1.0

# 文本线索标签（统一用这 5 类）
ALLOWED_TEXT_CLUES = ["污染", "模板量不足", "引物问题", "PCR体系问题", "退火温度问题"]
CSV_FALLBACK_ENCODINGS = ["utf-8", "utf-8-sig", "gb18030", "gbk", "cp936"]


def read_csv_with_fallback(file_path, **kwargs):
    """按常见编码顺序读取 CSV，优先 UTF-8，失败后回退中文编码。"""
    last_error = None
    for encoding in CSV_FALLBACK_ENCODINGS:
        try:
            return pd.read_csv(file_path, encoding=encoding, **kwargs)
        except UnicodeDecodeError as exc:
            last_error = exc

    if last_error is not None:
        raise last_error
    return pd.read_csv(file_path, **kwargs)


def ensure_page_config(page_title, page_icon="🧪"):
    """统一页面宽屏配置；重复调用时自动忽略。"""
    try:
        st.set_page_config(
            page_title=PRODUCT_NAME if page_title == PRODUCT_NAME else f"{PRODUCT_NAME}｜{page_title}",
            page_icon=page_icon,
            layout="wide",
            initial_sidebar_state="collapsed",
        )
    except Exception:
        pass


def init_access_state():
    """初始化首页入口与动态导航所需的会话状态。"""
    defaults = {
        "current_role": "home",
        "teacher_entered": False,
        "dev_entered": False,
        "teacher_verified": False,
        "dev_verified": False,
        "show_teacher_access_panel": False,
        "show_dev_access_panel": False,
        "active_access_dialog": None,
        "navigation_target": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def request_navigation(target):
    """记录下一次需要切换到的目标页面。"""
    st.session_state["navigation_target"] = target


def enter_student_role():
    st.session_state["current_role"] = "student"
    request_navigation("student")


def enter_teacher_role():
    st.session_state["teacher_entered"] = True
    st.session_state["teacher_verified"] = True
    st.session_state["show_teacher_access_panel"] = False
    st.session_state["current_role"] = "teacher"
    request_navigation("teacher")


def enter_dev_role():
    st.session_state["dev_entered"] = True
    st.session_state["dev_verified"] = True
    st.session_state["show_dev_access_panel"] = False
    st.session_state["current_role"] = "dev"
    request_navigation("dev")


def go_home(clear_entries=False):
    """返回首页；可选清空教师端/开发端入口状态。"""
    st.session_state["current_role"] = "home"
    st.session_state["active_access_dialog"] = None
    if clear_entries:
        st.session_state["teacher_entered"] = False
        st.session_state["dev_entered"] = False
        st.session_state["teacher_verified"] = False
        st.session_state["dev_verified"] = False
        st.session_state["show_teacher_access_panel"] = False
        st.session_state["show_dev_access_panel"] = False
    request_navigation("home")


def return_to_home(clear_entries=False):
    """返回首页视图：更新状态后真正切换到首页页对象。"""
    go_home(clear_entries=clear_entries)
    switch_to_home_page()


def switch_to_home_page():
    """真正切换到首页；若首页页对象尚未注册则安全回退为 rerun。"""
    home_page = get_home_page()
    if home_page is not None:
        st.switch_page(home_page)
        return
    st.rerun()


def get_current_role_label():
    role_map = {
        "home": "首页",
        "student": "学生",
        "teacher": "教师",
        "dev": "开发调试",
    }
    return role_map.get(st.session_state.get("current_role", "home"), "首页")


def get_config_value(name):
    """优先从 `.streamlit/secrets.toml` 读取，失败时回退到环境变量。"""
    if name in {"TEACHER_ACCESS_CODE", "DEV_ACCESS_CODE"} and is_demo_environment():
        return "demo-teacher" if name == "TEACHER_ACCESS_CODE" else "demo-dev"
    try:
        secret_value = st.secrets[name]
        normalized_secret = str(secret_value).strip()
        if normalized_secret:
            return normalized_secret
    except Exception:
        pass

    env_value = os.getenv(name, "")
    normalized_env = str(env_value or "").strip()
    return normalized_env or None


def get_teacher_access_code():
    return get_config_value("TEACHER_ACCESS_CODE")


def get_dev_access_code():
    return get_config_value("DEV_ACCESS_CODE")


def verify_access_code(input_code, expected_code):
    """轻量访问码校验；未配置时不放行。"""
    normalized_expected = str(expected_code or "").strip()
    normalized_input = str(input_code or "").strip()
    if not normalized_expected:
        return False
    return normalized_input == normalized_expected


def logout_teacher_access():
    st.session_state["teacher_verified"] = False
    st.session_state["teacher_entered"] = False
    st.session_state["show_teacher_access_panel"] = False
    st.session_state["active_access_dialog"] = None
    if st.session_state.get("current_role") == "teacher":
        st.session_state["current_role"] = "home"
    request_navigation("home")


def logout_dev_access():
    st.session_state["dev_verified"] = False
    st.session_state["dev_entered"] = False
    st.session_state["show_dev_access_panel"] = False
    st.session_state["active_access_dialog"] = None
    if st.session_state.get("current_role") == "dev":
        st.session_state["current_role"] = "home"
    request_navigation("home")


def render_entry_guard(page_name):
    """教师端/开发调试端的轻量访问拦截提示。"""
    with st.container(border=True):
        render_card_title("页面访问受限", f"当前会话尚未获得“{page_name}”入口。")
        st.warning(f"请先从首页的“{page_name}入口”完成访问码验证，再进入本页面。")
        col_home, col_reset = st.columns(2)
        with col_home:
            if st.button("返回首页", key=f"guard_home_{page_name}", use_container_width=True):
                return_to_home(clear_entries=False)
        with col_reset:
            if st.button("返回首页并重置入口状态", key=f"guard_reset_{page_name}", use_container_width=True):
                return_to_home(clear_entries=True)


def apply_common_styles(theme="student"):
    """所有角色共享同一视觉体系，theme 保留原调用兼容性。"""
    apply_design_system()




def render_card_title(title, desc=""):
    """卡片标题辅助函数"""
    st.markdown(f'<div class="pcr-card-title">{title}</div>', unsafe_allow_html=True)
    if desc:
        st.markdown(f'<div class="pcr-muted">{desc}</div>', unsafe_allow_html=True)


def render_info_tiles(items, columns=3):
    """横向信息卡片，用于首页说明与步骤展示。"""
    if not items:
        return

    cols = st.columns(columns)
    for index, item in enumerate(items):
        with cols[index % columns]:
            st.markdown(
                f"""
                <div class="pcr-tile">
                    <span class="pcr-tile-tag">{item.get("tag", "模块")}</span>
                    <h3>{item.get("title", "")}</h3>
                    <p>{item.get("desc", "")}</p>
                </div>
                """,
                unsafe_allow_html=True,
            )


def render_soft_notice(title, desc):
    """轻量提示卡。"""
    st.markdown(
        f"""
        <div class="pcr-soft-note">
            <div class="pcr-soft-note-title">{title}</div>
            <p>{desc}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_page_hero(title, subtitle, role_text=""):
    """统一的页面顶部 hero；首页可不显示左上角角标。"""
    badge_html = ""
    if str(role_text or "").strip():
        badge_html = f'<span class="pcr-role-badge">{role_text}</span>'

    st.markdown(
        f"""
        <div class="pcr-hero">
            {badge_html}
            <h1>{title}</h1>
            <p>{subtitle}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def run_system_self_check():
    """
    系统自检：
    检查关键组件是否可用，返回统一结构，避免单项失败影响全页。
    """
    checks = {}

    # 1) rules.csv 检查：文件存在且可读取
    try:
        if not os.path.exists(RULES_PATH):
            checks["rules_csv"] = {"level": "warning", "status": "未检测到", "detail": f"{RULES_PATH} 不存在"}
        else:
            read_csv_with_fallback(RULES_PATH)
            checks["rules_csv"] = {"level": "success", "status": "正常", "detail": "rules.csv 读取成功"}
    except Exception as e:
        checks["rules_csv"] = {"level": "error", "status": "失败", "detail": str(e)[:120]}

    # 2) SQLite 检查：可连接并执行简单查询
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        conn.close()
        checks["sqlite"] = {"level": "success", "status": "正常", "detail": "数据库连接正常"}
    except Exception as e:
        checks["sqlite"] = {"level": "error", "status": "失败", "detail": str(e)[:120]}

    # 3) uploads 目录检查
    if os.path.isdir(UPLOAD_DIR):
        checks["uploads"] = {"level": "success", "status": "正常", "detail": "上传目录可用"}
    else:
        checks["uploads"] = {"level": "warning", "status": "未创建", "detail": "上传目录尚未创建"}

    # 4) 环境变量检查
    api_key_exists = bool(ai_config.api_key())
    base_url_exists = True
    checks["bigmodel_api_key"] = {
        "level": "success" if api_key_exists else "warning",
        "status": "正常" if api_key_exists else "未检测到",
        "detail": "DEEPSEEK_API_KEY"
    }
    checks["bigmodel_base_url"] = {
        "level": "success" if base_url_exists else "warning",
        "status": "正常" if base_url_exists else "未检测到",
        "detail": ai_config.BASE_URL
    }
    checks["bigmodel_model"] = {
        "level": "success",
        "status": "正常",
        "detail": ai_config.MODEL
    }

    # 6) 文本抽取优先方式（当前代码逻辑）
    checks["extractor_strategy"] = {
        "level": "success",
        "status": "正常",
        "detail": "优先调用 DeepSeek 接口，失败时回退本地关键词规则"
    }

    return checks




def render_system_self_check():
    """渲染系统自检区域，使用统一状态卡布局。"""
    st.markdown("### 系统自检")
    checks = run_system_self_check()
    items = [
        ("rules_csv", "rules.csv 读取"),
        ("sqlite", "SQLite 数据库连接"),
        ("uploads", "uploads 文件夹"),
        ("bigmodel_api_key", "DEEPSEEK_API_KEY"),
        ("bigmodel_base_url", "DeepSeek 接口"),
        ("bigmodel_model", "当前模型"),
        ("extractor_strategy", "文本抽取优先方式"),
    ]

    cols = st.columns(3)
    level_class_map = {
        "success": "pcr-status-success",
        "warning": "pcr-status-warning",
        "error": "pcr-status-error",
    }
    for index, (key, label) in enumerate(items):
        item = checks.get(key, {"level": "warning", "status": "未知", "detail": ""})
        css_class = level_class_map.get(item["level"], "pcr-status-neutral")
        with cols[index % 3]:
            st.markdown(
                f"""
                <div class="pcr-status-card {css_class}">
                    <b>{label}：{item['status']}</b>
                    <p>{item['detail']}</p>
                </div>
                """,
                unsafe_allow_html=True,
            )


def run_rules_library_check():
    """
    规则库检查：
    返回 {"ok": bool, "issues": [...], "warnings": [...]}，用于页面显示。
    """
    issues = []
    warnings = []

    # 1) 文件存在与读取
    if not os.path.exists(RULES_PATH):
        issues.append(f"{RULES_PATH} 不存在")
        return {"ok": False, "issues": issues, "warnings": warnings}

    try:
        df = read_csv_with_fallback(RULES_PATH)
    except Exception as e:
        issues.append(f"rules.csv 读取失败：{str(e)[:120]}")
        return {"ok": False, "issues": issues, "warnings": warnings}

    # 2) 必要字段是否齐全
    missing_cols = [c for c in REQUIRED_RULE_COLUMNS if c not in df.columns]
    if missing_cols:
        issues.append(f"缺少必要字段：{', '.join(missing_cols)}")

    # 下面检查都在字段存在时进行，避免二次报错
    def count_empty(col_name):
        s = df[col_name]
        return int((s.isna() | (s.astype(str).str.strip() == "")).sum())

    # 3) 空字段检查
    if "abnormality" in df.columns:
        empty_abn = count_empty("abnormality")
        if empty_abn > 0:
            issues.append(f"abnormality 有空值：{empty_abn} 行")
    if "cause" in df.columns:
        empty_cause = count_empty("cause")
        if empty_cause > 0:
            issues.append(f"cause 有空值：{empty_cause} 行")
    if "suggestion" in df.columns:
        empty_suggestion = count_empty("suggestion")
        if empty_suggestion > 0:
            issues.append(f"suggestion 有空值：{empty_suggestion} 行")

    # 4) 分数字段检查：新版使用 base_score，旧版兼容 score
    score_column = "base_score" if "base_score" in df.columns else "score" if "score" in df.columns else None
    if score_column:
        score_num = pd.to_numeric(df[score_column], errors="coerce")
        invalid_score = int(score_num.isna().sum())
        if invalid_score > 0:
            issues.append(f"{score_column} 存在不可转数字值：{invalid_score} 行")

    # 5) 每种 abnormality 至少 1 条规则（按页面选项检查）
    if "abnormality" in df.columns:
        abn_series = df["abnormality"].astype(str).str.strip()
        normalized_options = {
            build_normalized_case({"abnormality": abn}).get("abnormality")
            for abn in ABNORMALITY_OPTIONS
        }
        allowed_values = set(ABNORMALITY_OPTIONS) | {value for value in normalized_options if value} | {"any"}
        for abn in ABNORMALITY_OPTIONS:
            normalized_abn = build_normalized_case({"abnormality": abn}).get("abnormality")
            if int(((abn_series == abn) | (abn_series == normalized_abn)).sum()) == 0:
                issues.append(f"实验现象“{abn}”缺少规则")

        # 可选提示：发现页面之外的 abnormality 值（不算硬错误）
        extra_values = sorted(set([x for x in abn_series if x and x not in allowed_values]))
        if extra_values:
            warnings.append(f"发现未在页面选项中的 abnormality：{', '.join(extra_values)}")

    return {"ok": len(issues) == 0, "issues": issues, "warnings": warnings}




def is_demo_environment():
    from pathlib import Path
    root = Path(__file__).resolve().parent / "data" / "demo"
    return (os.getenv("PCR_DIAGNOSIS_DEMO_MODE") == "1"
            and Path(DB_PATH).resolve() == root / "demo.db"
            and Path(UPLOAD_DIR).resolve() == root / "uploads")


def clear_history_records():
    """
    清空历史诊断记录（仅清数据，不删库、不删表结构）
    返回: (是否成功, 提示信息)
    """
    if not is_demo_environment():
        return False, "课堂数据库受保护，当前环境不允许清空记录。"
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # 删除前先统计总数（不要依赖 rowcount）
        cursor.execute("SELECT COUNT(*) FROM diagnosis_records")
        total_before = int(cursor.fetchone()[0] or 0)
        if cursor.execute("SELECT COUNT(*) FROM diagnosis_records WHERE coalesce(data_origin,'') NOT IN ('模拟演示','规则回归')").fetchone()[0]:
            conn.close()
            return False, "存在受保护的课堂记录，已停止清理。"

        cursor.execute("DELETE FROM diagnosis_records")
        cursor.execute("DELETE FROM teacher_review_history")
        cursor.execute("DELETE FROM student_revision_history")
        conn.commit()

        # 删除后再核对一次，用前后差值作为最终删除条数
        cursor.execute("SELECT COUNT(*) FROM diagnosis_records")
        total_after = int(cursor.fetchone()[0] or 0)
        deleted_count = max(total_before - total_after, 0)

        conn.close()
        return True, f"已清空历史诊断记录，共删除 {deleted_count} 条。"
    except Exception as e:
        return False, f"清空历史诊断记录失败：{str(e)[:120]}"


def clear_uploaded_images():
    """
    清空 uploads 下的测试图片文件。
    返回: (是否成功, 提示信息)
    """
    if not is_demo_environment():
        return False, "课堂上传目录受保护，当前环境不允许清空图片。"
    if not os.path.isdir(UPLOAD_DIR):
        return True, "uploads 文件夹不存在，无需清空。"

    # 删除前先统计当前文件数量
    files = [name for name in os.listdir(UPLOAD_DIR) if os.path.isfile(os.path.join(UPLOAD_DIR, name))]
    total_before = len(files)

    deleted_count = 0
    failed_count = 0
    failed_names = []

    for name in files:
        path = os.path.join(UPLOAD_DIR, name)
        try:
            os.remove(path)
            deleted_count += 1
        except Exception:
            failed_count += 1
            failed_names.append(name)

    if failed_count == 0:
        return True, f"已清空上传图片，共删除 {deleted_count} 个文件（删除前共 {total_before} 个）。"
    return False, f"部分图片删除失败：删除前共 {total_before}，成功 {deleted_count}，失败 {failed_count}（{', '.join(failed_names[:3])}）"


def init_database():
    return case_storage.init_database(DB_PATH)


def save_diagnosis_record(abnormality, template_amount, annealing_temp, cycles,
                          positive_control_normal, negative_control_band,
                          description, diagnosis_result, gel_image_path=None,
                          student_initial_hypothesis=None, student_access_code=None,
                          initial_results=None, raw_case=None, evidence=None):
    return case_storage.save_record(
        DB_PATH, abnormality, template_amount, annealing_temp, cycles,
        positive_control_normal, negative_control_band, description, diagnosis_result,
        gel_image_path, student_initial_hypothesis, student_access_code,
        initial_results, raw_case, evidence,
    )



def save_teacher_confirmation(record_id, teacher_final_cause, teacher_note,
                              evidence_level="经验复核", verification_feedback="", expected_version=None, rubric=None, data_origin=None):
    """每次复核生成版本，保留之前的结论和对应的学生修订。"""
    return case_storage.save_review(DB_PATH, record_id, teacher_final_cause, teacher_note,
                                   evidence_level, verification_feedback, expected_version, rubric, data_origin)



def save_followup_reassessment(record_id, diagnosis_result, positive_control_normal,
                               negative_control_band, followup_data):
    return case_storage.save_reassessment(DB_PATH, record_id, diagnosis_result,
                                         positive_control_normal, negative_control_band, followup_data)





def load_student_record(access_code):
    """凭私有查询码读取案例；数据库只保存查询码摘要。"""
    code = str(access_code or "").strip()
    if not code:
        return None
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM diagnosis_records WHERE student_access_hash = ?",
            (hashlib.sha256(code.encode("utf-8")).hexdigest(),),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def save_student_revision(record_id, access_code, revised_cause, revision_reason):
    return case_storage.save_revision(DB_PATH, record_id, access_code, revised_cause, revision_reason)


def save_verification_plan(record_id, access_code, plan):
    return case_storage.save_verification_plan(DB_PATH, record_id, access_code, plan)



def validate_uploaded_image(uploaded_file):
    """预览与保存共用图片检查，避免损坏文件中断页面。"""
    if uploaded_file is None:
        return None
    try:
        data = uploaded_file.getbuffer()
        if len(data) > 10 * 1024 * 1024:
            return "图片超过 10 MB，请缩小后再上传。"
        with Image.open(BytesIO(data)) as picture:
            if picture.format not in {"PNG", "JPEG"}:
                return "请上传有效的 PNG 或 JPG 图片。"
            picture.verify()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
        return "图片无法读取或文件已损坏，请重新导出为 PNG 或 JPG 后上传。"
    return None


def save_uploaded_image(uploaded_file):
    """
    保存上传图片到 uploads 目录。
    返回: (保存路径或None, 错误信息或None)
    """
    if uploaded_file is None:
        return None, None
    error = validate_uploaded_image(uploaded_file)
    if error:
        return None, error

    try:
        # 确保上传目录存在
        os.makedirs(UPLOAD_DIR, exist_ok=True)

        # 生成不重复文件名：时间戳 + uuid
        ext = os.path.splitext(uploaded_file.name)[1].lower()
        unique_name = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}{ext}"
        save_path = os.path.join(UPLOAD_DIR, unique_name)

        # 写入二进制文件
        with open(save_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        return save_path, None
    except Exception as e:
        return None, str(e)[:200]


def load_rules(path=RULES_PATH):
    """加载规则文件，支持多种编码兼容"""
    encodings = ["utf-8", "utf-8-sig", "gbk"]
    for enc in encodings:
        try:
            return pd.read_csv(path, encoding=enc)
        except UnicodeDecodeError:
            continue
        except Exception:
            break
    return pd.read_csv(path, encoding="utf-8", errors="replace")


def normalize_yes_no(value):
    """
    统一布尔值表示：
    支持“是/否”“yes/no”“true/false”等写法，最终转换为 yes/no
    """
    value_str = str(value).strip().lower()
    if value_str in ["是", "yes", "y", "true", "1"]:
        return "yes"
    if value_str in ["否", "no", "n", "false", "0"]:
        return "no"
    return value_str




def check_in_range(user_value, min_value, max_value):
    """检查用户数值是否在规则范围内；any 表示不限制"""
    min_v = safe_to_float(min_value, None)
    max_v = safe_to_float(max_value, None)

    if min_v is not None and user_value < min_v:
        return False
    if max_v is not None and user_value > max_v:
        return False
    return True


def normalize_text_clues(clues):
    """把各种同义写法归一到固定的 5 类线索标签"""
    alias_map = {
        "污染": "污染",
        "模板量不足": "模板量不足",
        "模板少": "模板量不足",
        "模板浓度低": "模板量不足",
        "引物问题": "引物问题",
        "引物失效": "引物问题",
        "PCR体系问题": "PCR体系问题",
        "体系漏加": "PCR体系问题",
        "退火温度问题": "退火温度问题",
        "退火温度过高": "退火温度问题",
        "退火温度过低": "退火温度问题",
    }

    normalized = []
    for c in clues:
        clue = str(c).strip()
        if not clue:
            continue
        clue = alias_map.get(clue, clue)
        if clue in ALLOWED_TEXT_CLUES and clue not in normalized:
            normalized.append(clue)
    return normalized


def mask_api_key(api_key):
    """只显示 key 前6位和后4位，中间隐藏，避免泄露"""
    key = str(api_key or "").strip()
    if not key:
        return ""
    if len(key) <= 10:
        return f"{key[:2]}***{key[-2:]}"
    return f"{key[:6]}***{key[-4:]}"


def filter_confirmed_description(description):
    """只保留明确的肯定事实，处理否定、疑问及中英文正常描述。"""
    return confirmed_description(description)



def extract_text_clues(description):
    """
    从学生补充描述中提取简单文本线索（关键词规则法）
    这是一个“伪 AI 抽取器”，用于先打通自由文本参与诊断的链路
    """
    text = filter_confirmed_description(description).lower()
    if not text:
        return []

    # 每类线索对应一组关键词（命中任意一个即可）
    clue_rules = {
        "污染": ["污染", "contam"],
        "模板量不足": ["模板量不足", "模板少", "模板浓度低", "模板太少"],
        "引物问题": ["引物问题", "引物失效", "引物降解", "primer degradation", "primer mismatch", "primer failure"],
        "PCR体系问题": ["体系漏加", "pcr体系问题", "体系问题", "漏加试剂", "漏加"],
        "退火温度问题": ["退火温度问题", "退火温度过高", "退火温度过低", "退火高", "退火低"],
    }

    clues = []
    for clue_name, keywords in clue_rules.items():
        if any(k in text for k in keywords):
            clues.append(clue_name)
    return normalize_text_clues(clues)


def parse_bigmodel_clues_response(content):
    """
    解析 BigModel 返回内容（宽松版）：
    1) 优先解析纯 JSON
    2) 再尝试从代码块/数组/对象中提取 JSON
    3) 最后做一次标签关键词兜底提取
    成功返回 (线索列表, None)，失败返回 (None, 失败原因)
    """
    raw = str(content or "").strip()
    if not raw:
        return None, "模型返回空结果"

    def _normalize_from_data(data):
        """从 list/dict 中提取并归一化线索"""
        if isinstance(data, list):
            return normalize_text_clues(data)
        if isinstance(data, dict):
            for key in ["clues", "labels", "result", "data"]:
                value = data.get(key)
                if isinstance(value, list):
                    return normalize_text_clues(value)
        return None

    # 1) 先试直接 JSON
    try:
        direct_data = json.loads(raw)
        clues = _normalize_from_data(direct_data)
        if clues is not None:
            if clues:
                return clues, None
            return None, "模型返回空结果"
    except:
        pass

    # 2) 再试提取 JSON 片段（代码块 / 数组 / 对象）
    candidates = []
    code_block_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw, flags=re.IGNORECASE)
    if code_block_match:
        candidates.append(code_block_match.group(1).strip())

    list_match = re.search(r"\[[\s\S]*\]", raw)
    if list_match:
        candidates.append(list_match.group(0).strip())

    obj_match = re.search(r"\{[\s\S]*\}", raw)
    if obj_match:
        candidates.append(obj_match.group(0).strip())

    for part in candidates:
        try:
            part_data = json.loads(part)
            clues = _normalize_from_data(part_data)
            if clues is not None:
                if clues:
                    return clues, None
                return None, "模型返回空结果"
        except:
            continue

    # 3) 最后做一次宽松文本兜底（直接查标签词）
    loose_clues = [label for label in ALLOWED_TEXT_CLUES if label in raw]
    loose_clues = normalize_text_clues(loose_clues)
    if loose_clues:
        return loose_clues, None

    return None, "返回内容不是合法 JSON"


def extract_text_clues_with_bigmodel(description, api_key, base_url, model):
    """
    优先调用 BigModel API 抽取文本线索。
    返回: (线索列表或None, 调试信息字典)
    """
    debug = {
        "bigmodel_called": False,
        "bigmodel_success": False,
        "fail_reason": "",
        "error_detail": "",
    }

    # 没安装 openai SDK：让上层回退
    if OpenAI is None:
        debug["fail_reason"] = "缺少 openai 依赖"
        return None, debug

    try:
        text = filter_confirmed_description(description).strip()
        if not text:
            debug["fail_reason"] = "描述中没有可确认的事实线索"
            return [], debug
        debug["bigmodel_called"] = True

        client = OpenAI(
            api_key=api_key,
            base_url=ai_config.BASE_URL,
            timeout=BIGMODEL_TIMEOUT_SECONDS,
            max_retries=0,
        )
        resp = client.chat.completions.create(
            **ai_config.request_options(),
            temperature=BIGMODEL_TEMPERATURE,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "你是PCR诊断文本线索抽取器。"
                        "只允许从以下标签中选择并输出："
                        "污染, 模板量不足, 引物问题, PCR体系问题, 退火温度问题。"
                        "只提取明确观察或核实的事实，不把猜测、提问、否定陈述或模型推断当成证据。"
                        "必须只输出一个JSON数组，不要输出任何其他文字。"
                    ),
                },
                {
                    "role": "user",
                    "content": f"学生补充描述：{text}",
                },
            ],
        )

        content = ""
        if resp and resp.choices and resp.choices[0].message:
            content = resp.choices[0].message.content or ""

        parsed, parse_error = parse_bigmodel_clues_response(content)
        if parsed is None:
            debug["fail_reason"] = parse_error or "返回内容解析失败"
            return None, debug

        debug["bigmodel_success"] = True
        return parsed, debug
    except Exception as e:
        debug["fail_reason"] = "DeepSeek API 请求失败"
        debug["error_detail"] = "接口未完成请求，请核对密钥、余额及网络。"
        return None, debug


def extract_text_clues_with_fallback(description):
    """
    抽取入口：
    1) 先走 DeepSeek 官方 API（保留旧函数名兼容调用）
    2) 失败后自动回退本地关键词抽取器
    返回：(线索列表, 抽取来源文案, 调试信息)
    """
    api_key = ai_config.api_key()
    base_url_env = ""
    base_url = ai_config.BASE_URL
    model = ai_config.MODEL

    debug_info = {
        "api_key_exists": bool(api_key),
        "base_url_exists": bool(base_url_env),
        "api_key_masked": mask_api_key(api_key),
        "extractor_used": "本地规则抽取",
        "fail_reason": "",
        "error_detail": "",
        "base_url": base_url,
        "model": model,
    }

    # 没有学生描述时，直接本地抽取（通常为空线索）
    text = str(description or "").strip()
    if not text:
        debug_info["fail_reason"] = "学生描述为空，未调用 DeepSeek"
        local_clues = extract_text_clues(description)
        return local_clues, "本地规则抽取", debug_info

    # 没有 key，直接本地兜底
    if not api_key:
        debug_info["fail_reason"] = "未读取到 DEEPSEEK_API_KEY"
        local_clues = extract_text_clues(description)
        return local_clues, "本地规则抽取", debug_info

    bigmodel_clues, bigmodel_debug = extract_text_clues_with_bigmodel(description, api_key, base_url, model)
    if bigmodel_clues is not None:
        debug_info["extractor_used"] = "AI（DeepSeek）抽取"
        return bigmodel_clues, "AI（DeepSeek）抽取", debug_info

    # DeepSeek 调用失败，记录失败原因并回退
    debug_info["fail_reason"] = bigmodel_debug.get("fail_reason", "DeepSeek 调用失败")
    debug_info["error_detail"] = bigmodel_debug.get("error_detail", "")

    local_clues = extract_text_clues(description)
    return local_clues, "本地规则抽取", debug_info


def calculate_text_clue_bonus(rule, text_clues, bonus_per_hit=5):
    """
    计算文本线索加分：
    若线索与当前规则的 cause/suggestion 关键词有关，则每命中一个线索加分
    """
    if not text_clues:
        return 0, []

    # 规则文本：用于做关键词包含判断
    rule_text = f"{rule.get('cause', '')} {rule.get('suggestion', '')}".lower()

    # 线索 -> 用于匹配规则文本的关键词
    clue_to_rule_keywords = {
        "污染": ["污染", "无菌", "超净台"],
        "模板量不足": ["模板", "模板量不足", "模板浓度过低"],
        "引物问题": ["引物"],
        "PCR体系问题": ["pcr体系", "体系", "漏加", "试剂"],
        "退火温度问题": ["退火温度", "提高退火温度", "降低退火温度", "温度过高", "温度过低"],
    }

    hit_clues = []
    for clue in text_clues:
        keywords = clue_to_rule_keywords.get(clue, [])
        if any(k in rule_text for k in keywords):
            hit_clues.append(clue)

    bonus = len(hit_clues) * bonus_per_hit
    return bonus, hit_clues


def calculate_score(rule, abnormality, template_amount, annealing_temp, cycles,
                    positive_control_normal, negative_control_band, text_clues=None):
    """
    计算规则匹配分数（宽松打分）
    只要实验现象一致，就进入候选集；其他条件按命中加分
    """
    # 1. 实验现象必须一致（进入候选集前提）
    if str(rule['abnormality']).strip() != str(abnormality).strip():
        return None

    # 2. 基础分（来自 rules.csv）
    base_score = safe_to_float(rule.get('score', 0), 0)
    score = base_score

    # 3. 后备规则仅对明确匹配的条件加分；any 不构成证据。
    rule_positive = normalize_yes_no(rule.get('positive_control_normal', 'any'))
    user_positive = normalize_yes_no(positive_control_normal)
    positive_hit = rule_positive != "any" and rule_positive == user_positive
    positive_add = 10 if positive_hit else 0
    score += positive_add

    # 4. 阴性对照
    rule_negative = normalize_yes_no(rule.get('negative_control_band', 'any'))
    user_negative = normalize_yes_no(negative_control_band)
    negative_hit = rule_negative != "any" and rule_negative == user_negative
    negative_add = 10 if negative_hit else 0
    score += negative_add

    # 5. 模板量在范围内加分
    # 加入体积不是 DNA 输入量；旧表的体积阈值不再作为模板量证据。
    template_hit = False
    template_add = 8 if template_hit else 0
    score += template_add

    # 6. 退火温度在范围内加分
    # 绝对温度需结合引物 Tm 与酶说明，旧表阈值不用于定性。
    temp_hit = False
    temp_add = 8 if temp_hit else 0
    score += temp_add

    # 7. 循环数在范围内加分（保留现有字段能力）
    cycles_hit = False
    cycles_add = 4 if cycles_hit else 0
    score += cycles_add

    # 8. 学生自由文本线索命中加分
    text_bonus, hit_clues = calculate_text_clue_bonus(rule, text_clues or [], bonus_per_hit=5)
    score += text_bonus

    # 返回总分 + 打分明细，便于前端展示“诊断依据”
    return {
        "总分": round(float(score), 2),
        "明细": {
            "基础分": round(float(base_score), 2),
            "阳性对照": {"命中": positive_hit, "加分": positive_add},
            "阴性对照": {"命中": negative_hit, "加分": negative_add},
            "模板量范围": {"命中": template_hit, "加分": template_add},
            "退火温度范围": {"命中": temp_hit, "加分": temp_add},
            "循环数范围": {"命中": cycles_hit, "加分": cycles_add},
            "文本线索": {
                "抽取线索": text_clues or [],
                "命中线索": hit_clues,
                "加分": text_bonus
            },
            "最终总分": round(float(score), 2)
        }
    }


def diagnose(abnormality, template_amount, annealing_temp, cycles,
             positive_control_normal, negative_control_band, description="",
             extra_text_hints=None, negative_control_detail=None, band_pattern=None,
             positive_control_detail=None, experiment_parameters=None, confirmed_text_hints=None):
    """
    诊断函数：根据输入的实验参数，返回可能的异常原因
    """
    # 从学生描述中抽取文本线索：优先 BigModel / GLM，失败回退本地关键词规则
    if confirmed_text_hints is None:
        text_clues, clue_source, api_debug = extract_text_clues_with_fallback(description)
    else:
        text_clues, clue_source, api_debug = list(confirmed_text_hints), "学生确认的事实线索", {}
    api_debug["normalized_case"] = build_normalized_case({
        **(experiment_parameters or {}),
        "abnormality": abnormality,
        "template_amount": template_amount,
        "annealing_temp": annealing_temp,
        "cycles": cycles,
        "positive_control_normal": positive_control_detail or positive_control_normal,
        "negative_control_band": negative_control_detail or negative_control_band,
        "description": description,
        "text_clues": list(text_clues) + list(extra_text_hints or []),
        "band_pattern": band_pattern,
    })
    try:
        api_debug["rules_v2_eval"] = evaluate_rules_v2(api_debug["normalized_case"])
        if (
            api_debug["rules_v2_eval"].get("status") == "ok"
            and api_debug["rules_v2_eval"].get("top1")
        ):
            primary_bundle = build_primary_diagnosis_from_rules_v2(api_debug["rules_v2_eval"])
            primary_results = primary_bundle.get("results", []) or []
            if primary_results:
                api_debug["primary_result_source"] = "rules_v2"
                return primary_results, True, text_clues, clue_source, api_debug
    except Exception as e:
        api_debug["rules_v2_error"] = str(e)[:200]

    fallback_results = diagnose_with_legacy_rules(
        abnormality,
        template_amount,
        annealing_temp,
        cycles,
        positive_control_normal,
        negative_control_band,
        text_clues=text_clues,
    )
    api_debug["primary_result_source"] = "legacy_fallback"
    api_debug["legacy_result_preview"] = fallback_results
    return fallback_results, bool(fallback_results), text_clues, clue_source, api_debug


def parse_top1_result(diagnosis_result):
    """
    从已保存的 diagnosis_result 文本中提取 Top1 原因和分数
    例如：1. 模板浓度过低 (总分:121.0); 2. ...
    """
    text = str(diagnosis_result or "").strip()
    if not text:
        return "未知", "-"

    # 取第一条（Top1）
    first_item = text.split(";")[0].strip()

    # 尝试按“1. 原因 (总分:xx)”格式解析
    match = re.match(r"^\d+\.\s*(.*?)\s*\(总分:\s*([^)]+)\)$", first_item)
    if match:
        return match.group(1).strip(), match.group(2).strip()

    # 兜底：至少返回可读文本
    first_item = re.sub(r"^\d+\.\s*", "", first_item)
    return first_item if first_item else "未知", "-"














def diagnose_with_legacy_rules(
    abnormality,
    template_amount,
    annealing_temp,
    cycles,
    positive_control_normal,
    negative_control_band,
    text_clues=None,
):
    rules = load_rules(LEGACY_RULES_PATH)
    candidate_rules = rules[rules["abnormality"].astype(str).str.strip() == str(abnormality).strip()]
    if candidate_rules.empty:
        return []

    results = []
    for _, rule in candidate_rules.iterrows():
        score_data = calculate_score(
            rule,
            abnormality,
            template_amount,
            annealing_temp,
            cycles,
            positive_control_normal,
            negative_control_band,
            text_clues=text_clues,
        )
        if score_data is None:
            continue
        results.append({
            "原因": rule["cause"],
            "总分": score_data["总分"],
            "建议": rule["suggestion"],
            "诊断依据": score_data["明细"],
        })

    return sorted(results, key=lambda item: item["总分"], reverse=True)[:3]
















def render_diagnosis_quality_block(
    top_results=None,
    candidate_texts=None,
    top1_reason="",
    top1_score=None,
    detail=None,
    abnormality="",
    positive_control_normal="",
    negative_control_band="",
    template_amount=None,
    annealing_temp=None,
    cycles=None,
    description="",
    text_clues=None,
    gel_image_path="",
    has_image=None,
    experiment_parameters=None,
    title="诊断证据支持解读",
):
    """统一渲染置信度 + 证据摘要 + 缺失信息提示"""
    ranked_results = build_ranked_results(
        top_results=top_results,
        candidate_texts=candidate_texts,
        top1_reason=top1_reason,
        top1_score=top1_score,
    )
    if not ranked_results:
        st.info("暂无可用于展示的证据支持信息。")
        return

    top1_result = ranked_results[0]
    detail = detail if detail is not None else (top1_result.get("诊断依据", {}) or {})
    context = build_diagnosis_context(
        abnormality=abnormality,
        positive_control_normal=positive_control_normal,
        negative_control_band=negative_control_band,
        template_amount=template_amount,
        annealing_temp=annealing_temp,
        cycles=cycles,
        description=description,
        text_clues=text_clues,
        gel_image_path=gel_image_path,
        has_image=has_image,
        experiment_parameters=experiment_parameters,
    )

    confidence_level, confidence_reason = compute_confidence_level(ranked_results, detail=detail, context=context)
    evidence_points = build_evidence_summary(top1_result.get("原因", top1_reason), detail=detail, context=context)
    missing_items = detect_missing_key_info({**context, "候选原因": top1_result.get("原因", top1_reason)})

    with st.container(border=True):
        st.markdown(f"**{title}**")
        metric_cols = st.columns(2)
        metric_cols[0].metric("证据支持程度", confidence_level)
        metric_cols[1].markdown(f"**判断说明**\n\n{confidence_reason}")

        st.markdown("**系统主要依据如下：**")
        if evidence_points:
            for point in evidence_points[:5]:
                st.markdown(f"- {point}")
        else:
            st.info("当前可提炼的证据较少，系统主要基于已有规则分值进行排序。")

        if missing_items:
            st.markdown("**为了提高判断准确性，建议补充以下信息：**")
            for item in missing_items:
                st.markdown(f"- {item}")
        else:
            st.success("当前未发现本候选要求的关键字段缺项，仍需结合实际实验复核。")


def load_recent_records(limit=10):
    """读取最近诊断记录（按时间倒序），返回摘要+详情所需字段"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT *
        FROM diagnosis_records
        ORDER BY diagnosis_time DESC, id DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()

    records = []
    for row in rows:
        data = dict(row)
        diagnosis_result = data.get("diagnosis_result", "")
        followup_data = parse_followup_data(data.get("followup_json"))

        # 学生补充描述过长时截断，避免摘要区过长
        desc_full = str(data.get("description") or "").strip()
        desc_short = desc_full
        if len(desc_short) > 30:
            desc_short = desc_short[:30] + "..."

        snapshot = parse_json(data.get("diagnosis_snapshot_json"))
        raw_case = parse_json(data.get("input_json"))
        stored_results = followup_data.get("final_results") or snapshot.get("results") or followup_data.get("initial_results")
        top_results = stored_results if isinstance(stored_results, list) else []
        if not top_results:
            top_results = build_ranked_results(candidate_texts=parse_all_candidates(diagnosis_result))
        top1_reason = top_results[0].get("原因", "") if top_results else ""
        top1_score = top_results[0].get("总分") if top_results else None
        all_candidates = [f"{i}. {item.get('原因', '未知')} (总分:{item.get('总分', '-')})" for i, item in enumerate(top_results, 1)]
        text_clues = snapshot.get("evidence", {}).get("text_clues", [])
        text_clues = list(dict.fromkeys(text_clues + followup_data.get("extra_hints", [])))
        normalized_case = snapshot.get("evidence", {}).get("normalized_case", {})
        rules_v2_eval = {}
        gel_image_path = data.get("gel_image_path")
        has_image = bool(gel_image_path)

        records.append({
            "id": data.get("id"),
            "提交时间": data.get("diagnosis_time", "-"),
            "实验现象": data.get("abnormality", "-"),
            "模板量": data.get("template_amount", "-"),
            "退火温度": data.get("annealing_temp", "-"),
            "循环数": data.get("cycles", "-"),
            "阳性对照是否正常": data.get("positive_control_normal", "-"),
            "阴性对照是否有带": data.get("negative_control_band", "-"),
            "学生补充描述": desc_full if desc_full else "-",
            "学生补充描述摘要": desc_short if desc_short else "-",
            "抽取到的文本线索": text_clues,
            "Top1 原因": top1_reason,
            "Top1 分数": top1_score,
            "候选原因列表": all_candidates,
            "系统结果列表": top_results,
            "rules_v2_eval": rules_v2_eval,
            "教师最终原因": data.get("teacher_final_cause") if data.get("teacher_final_cause") else "未确认",
            "教师备注": data.get("teacher_note") if data.get("teacher_note") else "-",
            "教师确认时间": data.get("teacher_confirm_time") if data.get("teacher_confirm_time") else "-",
            "学生初判": data.get("student_initial_hypothesis") or "-",
            "学生修订原因": data.get("student_revised_cause") or "-",
            "学生修订依据": data.get("student_revision_reason") or "-",
            "学生修订时间": data.get("student_revision_time") or "-",
            "凝胶图路径": gel_image_path if gel_image_path else "",
            "凝胶图": "有图" if has_image else "无图",
            "normalized_case": normalized_case,
            "followup_data": followup_data,
            "input_data": raw_case,
            "snapshot": snapshot,
            **{k: data.get(k) for k in case_storage.ADDITIONAL_COLUMNS},
        })

    return records


def load_record_by_id(record_id):
    """按 id 读取单条记录（用于导出案例摘要）"""
    if not record_id:
        return None

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM diagnosis_records WHERE id = ?", (record_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def load_case_history(record_id):
    """读取复核与修订的版本记录，不重算历史诊断。"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        return {
            "teacher": [dict(row) for row in conn.execute("SELECT * FROM teacher_review_history WHERE record_id=? ORDER BY review_version", (record_id,))],
            "student": [dict(row) for row in conn.execute("SELECT * FROM student_revision_history WHERE record_id=? ORDER BY review_version", (record_id,))],
        }
    finally:
        conn.close()

















def build_case_review_report(payload):
    return experiment_business.build_case_review_report(payload, DB_PATH)


def _build_case_summary_legacy(payload):
    """
    生成结构化案例摘要文本（txt内容）
    优先使用数据库已保存值，缺失时回退到当前内存 payload
    """
    record_id = payload.get("record_id")
    db_record = load_record_by_id(record_id) or {}

    # 诊断输入参数
    submit_time = db_record.get("diagnosis_time") or payload.get("submit_time", "-")
    abnormality = db_record.get("abnormality") or payload.get("abnormality", "-")
    template_amount = db_record.get("template_amount", payload.get("template_amount", "-"))
    annealing_temp = db_record.get("annealing_temp", payload.get("annealing_temp", "-"))
    cycles = db_record.get("cycles", payload.get("cycles", "-"))
    positive_control = db_record.get("positive_control_normal") or payload.get("positive_control_normal", "-")
    negative_control = db_record.get("negative_control_band") or payload.get("negative_control_band", "-")
    description = db_record.get("description") or payload.get("description", "-")

    # 文本线索、Top3
    text_clues = payload.get("text_clues", [])
    top_results = payload.get("results", [])
    top_lines = []
    for i, item in enumerate(top_results, 1):
        top_lines.append(f"{i}. {item.get('原因', '未知')}（总分: {item.get('总分', '-')})")
    top_lines_text = "\n".join(top_lines) if top_lines else "无"

    # Top1 主要依据（简要）
    top1_basis = "无"
    if top_results:
        detail = top_results[0].get("诊断依据", {})
        top1_basis = (
            f"基础分{detail.get('基础分', 0)}；"
            f"阳性对照加分{detail.get('阳性对照', {}).get('加分', 0)}；"
            f"阴性对照加分{detail.get('阴性对照', {}).get('加分', 0)}；"
            f"模板量加分{detail.get('模板量范围', {}).get('加分', 0)}；"
            f"退火温度加分{detail.get('退火温度范围', {}).get('加分', 0)}；"
            f"文本线索加分{detail.get('文本线索', {}).get('加分', 0)}"
        )

    # 教师确认信息
    teacher_final = db_record.get("teacher_final_cause") or "未确认"
    teacher_note = db_record.get("teacher_note") or "无"

    # 图片信息
    image_path = db_record.get("gel_image_path") or payload.get("gel_image_path", "")
    has_image = "是" if image_path else "否"

    lines = [
        f"【{PRODUCT_NAME} · 案例摘要】",
        PRODUCT_SUBTITLE,
        f"当前模块：{CURRENT_MODULE}",
        f"记录ID：{record_id if record_id else '无'}",
        f"提交时间：{submit_time}",
        f"实验现象：{abnormality}",
        f"模板量：{template_amount}",
        f"退火温度：{annealing_temp}",
        f"循环数：{cycles}",
        f"阳性对照是否正常：{positive_control}",
        f"阴性对照是否有带：{negative_control}",
        f"学生补充描述：{description if description else '无'}",
        f"抽取到的文本线索：{'、'.join(text_clues) if text_clues else '无'}",
        "Top 3 诊断结果：",
        top_lines_text,
        f"Top1主要诊断依据：{top1_basis}",
        f"教师最终原因：{teacher_final}",
        f"教师备注：{teacher_note}",
        f"是否上传图片：{has_image}",
    ]
    return "\n".join(lines)


def build_case_summary(payload):
    return experiment_business.build_case_summary(payload, DB_PATH)


# ---------- 规则库编辑相关函数 ----------
def check_rule_duplicate(new_rule, existing_df):
    """
    检查新规则是否与现有规则完全重复。
    重复定义：abnormality 和 cause 完全相同。
    返回：(is_duplicate, 重复的行索引列表)
    """
    if existing_df.empty:
        return False, []
    new_abn = str(new_rule.get("abnormality", "")).strip()
    new_cause = str(new_rule.get("cause", "")).strip()
    mask = (existing_df["abnormality"].astype(str).str.strip() == new_abn) & \
           (existing_df["cause"].astype(str).str.strip() == new_cause)
    duplicate_indices = existing_df[mask].index.tolist()
    return len(duplicate_indices) > 0, duplicate_indices


def check_rule_conflict(new_rule, existing_df):
    """
    检查新规则与现有规则是否存在潜在冲突。
    冲突定义：同一 abnormality 下，新规则的数值范围与已有规则重叠，且总分差异较大（>10分）。
    返回：冲突描述列表（每项为字符串）。
    """
    conflicts = []
    new_abn = str(new_rule.get("abnormality", "")).strip()
    same_abn_df = existing_df[existing_df["abnormality"].astype(str).str.strip() == new_abn]
    if same_abn_df.empty:
        return conflicts

    # 解析新规则的数值边界（any 表示无限制）
    def parse_range(min_val, max_val):
        min_v = safe_to_float(min_val, None)
        max_v = safe_to_float(max_val, None)
        return min_v, max_v

    new_min_tpl, new_max_tpl = parse_range(new_rule.get("min_template"), new_rule.get("max_template"))
    new_min_temp, new_max_temp = parse_range(new_rule.get("min_temp"), new_rule.get("max_temp"))
    new_score = safe_to_float(new_rule.get("score"), 0)

    for idx, row in same_abn_df.iterrows():
        exist_min_tpl, exist_max_tpl = parse_range(row.get("min_template"), row.get("max_template"))
        exist_min_temp, exist_max_temp = parse_range(row.get("min_temp"), row.get("max_temp"))
        exist_score = safe_to_float(row.get("score"), 0)

        # 检查模板量范围重叠
        tpl_overlap = False
        if new_min_tpl is None or exist_min_tpl is None:
            tpl_overlap = True
        else:
            if new_max_tpl is not None and exist_max_tpl is not None:
                tpl_overlap = not (new_max_tpl < exist_min_tpl or exist_max_tpl < new_min_tpl)
            else:
                tpl_overlap = True

        # 检查退火温度范围重叠
        temp_overlap = False
        if new_min_temp is None or exist_min_temp is None:
            temp_overlap = True
        else:
            if new_max_temp is not None and exist_max_temp is not None:
                temp_overlap = not (new_max_temp < exist_min_temp or exist_max_temp < new_min_temp)
            else:
                temp_overlap = True

        if tpl_overlap and temp_overlap and abs(new_score - exist_score) > 10:
            conflicts.append(
                f"与行 {idx} 的规则（原因：{row.get('cause', '')}，"
                f"模板量范围 {row.get('min_template')}~{row.get('max_template')}，"
                f"温度范围 {row.get('min_temp')}~{row.get('max_temp')}，"
                f"分数 {exist_score}）存在重叠且分数差异较大，可能造成诊断歧义。"
            )

    return conflicts


def append_rule_to_csv(new_rule_dict, rules_path=RULES_PATH):
    """
    将新规则追加写入 CSV 文件。
    返回：(是否成功, 消息)
    """
    try:
        # 读取原有数据以保留列顺序；rules.csv 可能由 Excel 以 GBK/GB18030 保存
        if os.path.exists(rules_path):
            df_existing = read_csv_with_fallback(rules_path)
            target_columns = list(df_existing.columns) if len(df_existing.columns) else list(REQUIRED_RULE_COLUMNS)
        else:
            df_existing = pd.DataFrame(columns=REQUIRED_RULE_COLUMNS)
            target_columns = list(REQUIRED_RULE_COLUMNS)

        normalized_rule = {column: new_rule_dict.get(column, "") for column in target_columns}
        new_row_df = pd.DataFrame([normalized_rule], columns=target_columns)
        updated_df = pd.concat([df_existing, new_row_df], ignore_index=True)

        # 写回文件（统一为 utf-8-sig，便于 Excel 打开）
        updated_df.to_csv(rules_path, index=False, encoding="utf-8-sig")
        return True, "新规则已成功添加。"
    except Exception as e:
        return False, f"写入规则文件失败：{str(e)[:120]}"
