"""平台与模块名称、说明的统一来源。"""

PRODUCT_NAME = "生物实验智学平台"
PRODUCT_SUBTITLE = "面向本科生物实验教学的知识探索与智能复盘平台"
KNOWLEDGE_MODULE_NAME = "生物功能图谱"
KNOWLEDGE_MODULE_DESCRIPTION = "探索基因、蛋白与代谢物的通路关联"
EXPERIMENT_MODULE_NAME = "实验探因与复盘"
EXPERIMENT_MODULE_DESCRIPTION = "记录实验现象，在证据与反馈中改进判断"
CURRENT_MODULE = EXPERIMENT_MODULE_NAME
CURRENT_EXPERIMENT = "PCR 与电泳"
